package kaptainwutax.seedcrackerX.util;

import com.mojang.authlib.HttpAuthenticationService;
import com.mojang.authlib.exceptions.AuthenticationException;
import com.mojang.authlib.exceptions.AuthenticationUnavailableException;
import com.mojang.authlib.exceptions.InsufficientPrivilegesException;
import kaptainwutax.seedcrackerX.SeedCracker;
import kaptainwutax.seedcrackerX.config.Config;
import kaptainwutax.seedcrackerX.finder.Finder;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import org.jetbrains.annotations.Nullable;

import java.net.HttpURLConnection;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.time.Instant;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class Database {

    private static final String DATABASE_POST_URL = "https://script.google.com/macros/s/AKfycbye87L-fEYq2EkgczvhKb_kGecp5wL1oX95vg45TRSwNvpv7K-53zoInGTeI1FZ0kv7DA/exec";
    private static final String DATABASE_URL = "https://docs.google.com/spreadsheets/d/1tuQiE-0leW88em9OHbZnH-RFNhVqgoHhIt9WQbeqqWw/export?format=csv&gid=0";
    private static final HttpClient HTTP_CLIENT = HttpClient.newBuilder()
        .connectTimeout(Duration.ofSeconds(10))
        .followRedirects(HttpClient.Redirect.NORMAL)
        .build();
    private static final Duration TIMEOUT = Duration.ofSeconds(10);
    private static final String USER_AGENT = "SeedCrackerKiller/2.15.6-killer.1 (SeedCrackerX compatible)";

    private static final Map<String, Long> connectionToSeed = new ConcurrentHashMap<>();
    private static final Map<Long, Long> hashedSeedToSeed = new ConcurrentHashMap<>();
    private static volatile Instant lastSuccessfulFetch;
    private static volatile String lastError;

    private Database() {
    }

    public static Component joinFakeServerForAuth() {
        try {
            Minecraft client = Minecraft.getInstance();
            // Keep the original service identifier for compatibility with the existing backend.
            client.services().sessionService().joinServer(client.getUser().getProfileId(), client.getUser().getAccessToken(), "seedcrackerx");
        } catch (AuthenticationUnavailableException exception) {
            return Component.translatable("disconnect.loginFailedInfo", Component.translatable("disconnect.loginFailedInfo.serversUnavailable"));
        } catch (InsufficientPrivilegesException exception) {
            return Component.translatable("disconnect.loginFailedInfo", Component.translatable("disconnect.loginFailedInfo.insufficientPrivileges"));
        } catch (AuthenticationException exception) {
            return Component.translatable("disconnect.loginFailedInfo", exception.getMessage());
        }
        return null;
    }

    public static @Nullable Long getSeed(String connection, long hashedSeed) {
        Long seed = connectionToSeed.get(connection);
        return seed != null ? seed : hashedSeedToSeed.get(hashedSeed);
    }

    public static int getConnectionEntryCount() {
        return connectionToSeed.size();
    }

    public static int getHashedEntryCount() {
        return hashedSeedToSeed.size();
    }

    public static @Nullable Instant getLastSuccessfulFetch() {
        return lastSuccessfulFetch;
    }

    public static @Nullable String getLastError() {
        return lastError;
    }

    public static void handleDatabaseCall(Long seed) {
        Minecraft client = Minecraft.getInstance();
        if (client.getConnection() == null || client.level == null || client.player == null) {
            lastError = "No active game connection";
            Log.warn("database.fail");
            return;
        }

        Map<String, Object> data = new HashMap<>();
        data.put("serverIp", client.getConnection().getConnection().getRemoteAddress().toString());
        data.put("dimension", Finder.inferDimension(client.level.dimensionType()));
        data.put("seed", seed + "L");
        data.put("version", Config.get().getVersion().name);
        data.put("username", client.player.getName().getString());
        data.put("hash", Config.get().anonymusSubmits ? 1 : 0);

        HttpRequest request = HttpRequest.newBuilder(URI.create(DATABASE_POST_URL))
            .timeout(TIMEOUT)
            .POST(HttpRequest.BodyPublishers.ofString(HttpAuthenticationService.buildQuery(data)))
            .setHeader("User-Agent", USER_AGENT)
            .header("Content-Type", "application/x-www-form-urlencoded")
            .build();

        HTTP_CLIENT.sendAsync(request, HttpResponse.BodyHandlers.discarding())
            .thenAccept(response -> {
                int status = response.statusCode();
                if ((status >= 200 && status < 300) || status == HttpURLConnection.HTTP_MOVED_TEMP) {
                    lastError = null;
                    Log.warn("database.success");
                } else {
                    lastError = "HTTP " + status;
                    Log.warn("database.fail");
                }
            })
            .exceptionally(exception -> {
                recordFailure("Database submission", exception);
                Log.warn("database.fail");
                return null;
            });
    }

    public static void fetchSeeds() {
        HttpRequest request = HttpRequest.newBuilder(URI.create(DATABASE_URL))
            .timeout(TIMEOUT)
            .GET()
            .setHeader("User-Agent", USER_AGENT)
            .build();

        HTTP_CLIENT.sendAsync(request, HttpResponse.BodyHandlers.ofString())
            .thenApply(response -> {
                if (response.statusCode() < 200 || response.statusCode() >= 300) {
                    throw new IllegalStateException("HTTP " + response.statusCode());
                }
                return response.body();
            })
            .thenAccept(Database::parseCsv)
            .exceptionally(exception -> {
                recordFailure("Database download", exception);
                return null;
            });
    }

    private static void parseCsv(String csv) {
        Map<String, Long> newConnections = new HashMap<>();
        Map<Long, Long> newHashes = new HashMap<>();

        Arrays.stream(csv.split("\\R")).skip(1).forEach(row -> {
            try {
                String[] seedEntry = row.split(",", -1);
                String connection = seedEntry[0].trim();
                String seedString = seedEntry[2].trim();
                if (seedString.endsWith("L")) {
                    seedString = seedString.substring(0, seedString.length() - 1);
                }
                long seed = Long.parseLong(seedString);
                long hashedSeed = Long.parseLong(seedEntry[6].trim());
                if (!connection.isEmpty()) {
                    newConnections.put(connection, seed);
                }
                newHashes.put(hashedSeed, seed);
            } catch (NumberFormatException | ArrayIndexOutOfBoundsException ignored) {
                // Ignore malformed or incomplete rows without discarding valid records.
            }
        });

        if (!newConnections.isEmpty() || !newHashes.isEmpty()) {
            connectionToSeed.clear();
            connectionToSeed.putAll(newConnections);
            hashedSeedToSeed.clear();
            hashedSeedToSeed.putAll(newHashes);
            lastSuccessfulFetch = Instant.now();
            lastError = null;
            SeedCracker.LOGGER.info("Loaded {} connection seeds and {} hashed seeds from the SeedCrackerX database", newConnections.size(), newHashes.size());
        } else {
            lastError = "Database response contained no valid entries";
            SeedCracker.LOGGER.warn(lastError);
        }
    }

    private static void recordFailure(String operation, Throwable exception) {
        Throwable cause = exception.getCause() != null ? exception.getCause() : exception;
        lastError = cause.getClass().getSimpleName() + ": " + String.valueOf(cause.getMessage());
        SeedCracker.LOGGER.warn("{} failed: {}", operation, lastError);
    }
}
