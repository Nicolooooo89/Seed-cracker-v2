package kaptainwutax.seedcrackerX.command;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import kaptainwutax.seedcrackerX.SeedCracker;
import kaptainwutax.seedcrackerX.config.Config;
import kaptainwutax.seedcrackerX.cracker.storage.DataStorage;
import kaptainwutax.seedcrackerX.cracker.storage.TimeMachine;
import kaptainwutax.seedcrackerX.util.Database;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.ChatFormatting;

import java.time.Duration;
import java.time.Instant;
import java.util.Locale;

public class StatusCommand extends ClientCommand {

    @Override
    public String getName() {
        return "status";
    }

    @Override
    public void build(LiteralArgumentBuilder<FabricClientCommandSource> builder) {
        builder.executes(this::showStatus);
    }

    private int showStatus(CommandContext<FabricClientCommandSource> context) {
        DataStorage storage = SeedCracker.get().getDataStorage();
        Config config = Config.get();

        sendFeedback("SeedCrackerKiller 2.15.6-killer.1 — Minecraft 1.21.11", ChatFormatting.AQUA, false);
        sendFeedback(
            "Engine: " + (config.active ? "active" : "paused")
                + " | Cracking: " + (storage.isCracking() ? "running" : "idle")
                + " | Workers: " + TimeMachine.CRACKER_THREADS
                + " | Analysis version: " + config.getVersion().name,
            config.active ? ChatFormatting.GREEN : ChatFormatting.YELLOW,
            false
        );
        sendFeedback(
            String.format(
                Locale.ROOT,
                "Evidence: %d base (%.2f/%.2f bits) | %d biome | %.2f decorator bits",
                storage.getBaseDataCount(),
                storage.getBaseBits(),
                storage.getWantedBits(),
                storage.getBiomeDataCount(),
                storage.getDecoratorBits()
            ),
            ChatFormatting.GRAY,
            false
        );
        sendFeedback(
            "Candidates: " + storage.getStructureSeedCandidateCount() + " structure | "
                + storage.getWorldSeedCandidateCount() + " world",
            ChatFormatting.GRAY,
            false
        );

        String databaseAge = formatDatabaseAge(Database.getLastSuccessfulFetch());
        String databaseStatus = "Database: " + Database.getConnectionEntryCount() + " connections | "
            + Database.getHashedEntryCount() + " hashes | refreshed " + databaseAge;
        sendFeedback(databaseStatus, Database.getLastError() == null ? ChatFormatting.GREEN : ChatFormatting.YELLOW, false);

        if (Database.getLastError() != null) {
            sendFeedback("Last database error: " + Database.getLastError(), ChatFormatting.YELLOW, false);
        }
        return 1;
    }

    private static String formatDatabaseAge(Instant fetchTime) {
        if (fetchTime == null) {
            return "never";
        }
        long seconds = Math.max(0, Duration.between(fetchTime, Instant.now()).getSeconds());
        if (seconds < 60) {
            return seconds + "s ago";
        }
        long minutes = seconds / 60;
        if (minutes < 60) {
            return minutes + "m ago";
        }
        return (minutes / 60) + "h ago";
    }
}
