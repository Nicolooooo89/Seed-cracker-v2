package kaptainwutax.seedcrackerX;

import com.mojang.logging.LogUtils;
import kaptainwutax.seedcrackerX.api.SeedCrackerAPI;
import kaptainwutax.seedcrackerX.config.Config;
import kaptainwutax.seedcrackerX.cracker.storage.DataStorage;
import kaptainwutax.seedcrackerX.finder.FinderQueue;
import kaptainwutax.seedcrackerX.init.ClientCommands;
import kaptainwutax.seedcrackerX.util.Database;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;

import java.util.ArrayList;

public class SeedCracker implements net.fabricmc.api.ClientModInitializer {
    public static final Logger LOGGER = LogUtils.getLogger();
    public static final ArrayList<SeedCrackerAPI> entrypoints = new ArrayList<>();
    private static SeedCracker INSTANCE;
    private final DataStorage dataStorage = new DataStorage();

    public static SeedCracker get() {
        return INSTANCE;
    }

    @Override
    public void onInitializeClient() {
        INSTANCE = this;
        Config.load();
        ClientCommands.PREFIX = Config.get().commandPrefix;

        try {
            // Attempt to use the 4-argument constructor which is common in Mojang mappings
            java.lang.reflect.Constructor<net.minecraft.client.KeyMapping> constr = net.minecraft.client.KeyMapping.class.getConstructor(
                String.class, com.mojang.blaze3d.platform.InputConstants.Type.class, int.class, String.class);
            ClientCommands.PANIC_KEY = net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper.registerKeyBinding(
                constr.newInstance("key.seedcrackerkiller.panic", com.mojang.blaze3d.platform.InputConstants.Type.KEYSYM, com.mojang.blaze3d.platform.InputConstants.KEY_P, "key.categories.misc"));
        } catch (Exception e) {
            try {
                // Fallback for 3-argument constructor (String, int, String)
                java.lang.reflect.Constructor<net.minecraft.client.KeyMapping> constr = net.minecraft.client.KeyMapping.class.getConstructor(
                    String.class, int.class, String.class);
                ClientCommands.PANIC_KEY = net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper.registerKeyBinding(
                    constr.newInstance("key.seedcrackerkiller.panic", com.mojang.blaze3d.platform.InputConstants.KEY_P, "key.categories.misc"));
            } catch (Exception e2) {
                LOGGER.error("Failed to register panic key via reflection", e2);
            }
        }
        Features.init(Config.get().getVersion());
        FabricLoader loader = FabricLoader.getInstance();
        loader.getEntrypointContainers("seedcrackerx", SeedCrackerAPI.class).forEach(entrypoint ->
            entrypoints.add(entrypoint.getEntrypoint()));
        loader.getEntrypointContainers("seedcrackerkiller", SeedCrackerAPI.class).forEach(entrypoint -> {
            SeedCrackerAPI api = entrypoint.getEntrypoint();
            if (!entrypoints.contains(api)) {
                entrypoints.add(api);
            }
        });

        FinderQueue.registerEvents();

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> ClientCommands.registerCommands(dispatcher));

        Database.fetchSeeds();
        LOGGER.info("SeedCrackerKiller 2.15.6-killer.1 initialized for Minecraft 1.21.11; based on SeedCrackerX by KaptainWutax and 19MisterX98");
    }

    public DataStorage getDataStorage() {
        return this.dataStorage;
    }

    public void reset() {
        SeedCracker.get().getDataStorage().clear();
        FinderQueue.get().finderControl.deleteFinders();
    }
}
