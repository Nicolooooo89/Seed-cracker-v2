package kaptainwutax.seedcrackerX.mixin;

import kaptainwutax.seedcrackerX.SeedCracker;
import net.minecraft.client.player.LocalPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LocalPlayer.class)
public abstract class LocalPlayerMixin {

    @Inject(method = "tick", at = @At("HEAD"))
    private void tick(CallbackInfo ci) {
        SeedCracker.get().getDataStorage().tick();
        
        if (kaptainwutax.seedcrackerX.init.ClientCommands.PANIC_KEY != null) {
            while (kaptainwutax.seedcrackerX.init.ClientCommands.PANIC_KEY.consumeClick()) {
                kaptainwutax.seedcrackerX.config.Config.get().panicMode = !kaptainwutax.seedcrackerX.config.Config.get().panicMode;
                kaptainwutax.seedcrackerX.config.Config.save();
            }
        }
    }

}
