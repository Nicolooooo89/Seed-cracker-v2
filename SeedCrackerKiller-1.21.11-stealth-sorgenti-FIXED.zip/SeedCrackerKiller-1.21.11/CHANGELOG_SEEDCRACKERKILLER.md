# Changelog SeedCrackerKiller

## 2.15.6-killer.1 — Minecraft 1.21.11

Questa versione è basata sul tag `2.15.6` (commit `4551964999b5a81acbfb0257bf21548f683498fe`) del repository originale [19MisterX98/SeedcrackerX](https://github.com/19MisterX98/SeedcrackerX).

| Area | Modifica |
|---|---|
| Compatibilità | Base aggiornata e verificata per Minecraft 1.21.11, Java 21, Fabric Loader 0.18.2 e Fabric API 0.139.4+1.21.11. |
| Identità | Artefatto rinominato `seedcrackerkiller`; mod ID separato `seedcrackerkiller`; licenza, autori e fonti upstream preservati. |
| Prestazioni | Worker di cracking adattivi: minimo 4, massimo 8, calcolati dai processori disponibili; un thread aggiuntivo resta dedicato all’orchestrazione. |
| Diagnostica | Nuovo comando `/seedcracker status` con stato motore, numero worker, evidenze, bit, candidati e salute del database. |
| Rete | Download e invio database asincroni con timeout di connessione e richiesta, validazione dello stato HTTP e registrazione dell’ultimo errore. |
| Concorrenza | Cache del database convertite in mappe concorrenti; aggiornamento atomico dei record validi. |
| Robustezza | Le righe CSV malformate vengono ignorate senza scartare i dati validi; una risposta interamente invalida non svuota la cache esistente. |
| Configurazione | File separato `seedcrackerkiller.json`, così il port non sovrascrive `seedcracker.json`; se esiste soltanto il file storico, viene importato automaticamente una volta. |
| API | Supportati sia l’entrypoint storico `seedcrackerx` sia quello nuovo `seedcrackerkiller`, con rimozione dei duplicati. |
| Privacy | L’invio al database resta disattivato per impostazione predefinita, come nella configurazione upstream. Il comando `status` non mostra seed, server o nome utente. |

> Nessuna modifica è stata introdotta nelle formule matematiche di cracking o nei criteri di riconoscimento delle strutture. Il potenziamento riguarda parallelismo, osservabilità e affidabilità, riducendo il rischio di risultati errati.
